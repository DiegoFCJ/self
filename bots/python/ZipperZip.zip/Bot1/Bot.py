import time

def main():
    print("Bot3 ha iniziato l'esecuzione...")

    # Fase 1
    print("Fase 1: Attesa per 30 secondi...")
    time.sleep(30)
    print("Fase 1 completata!")

    # Fase 2
    print("Fase 2: Attesa per 30 secondi...")
    time.sleep(30)
    print("Fase 2 completata!")

    # Fase 3
    print("Fase 3: Attesa per 1 minuto...")
    time.sleep(60)
    print("Fase 3 completata!")

    print("Bot3 ha completato l'esecuzione.")

if __name__ == "__main__":
    main()